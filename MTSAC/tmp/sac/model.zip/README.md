Unzip the model here and remove the outer folder
